enum AuthStatus {
  loggedIn,
  notLoggedIn,
}
