class ReservModel{
 bool servisSecildi;

  ReservModel({
    this.servisSecildi = false,
});

}